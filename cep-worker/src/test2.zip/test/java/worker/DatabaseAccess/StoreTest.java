package worker.DatabaseAccess;

import com.fiftyonred.mock_jedis.MockJedis;
import junit.framework.TestCase;

import java.util.HashSet;
import java.util.Set;
import redis.clients.jedis.Jedis;

public class StoreTest extends TestCase{


    public void testBasic(){
        Jedis j = new MockJedis("REDIS_HOST");
        Store store = new Store(j);

        j.sadd("EventTypes","1");
        j.set("1:Name","MyAvroEvent");
        j.set("1:Definition","SELECT * FROM Position");
        j.set("1:Worker","43");
        j.sadd("1:Inputs","Position");


        assertEquals("MyAvroEvent",store.getEventTypeName("1"));
        assertEquals("SELECT * FROM Position",store.getEventTypeDefinition("1"));
        assertEquals("43",store.getEventTypeCurrentWorker("1"));





        assertEquals("Position",store.getEventTypeInputs("1").iterator().next());
    }


}

