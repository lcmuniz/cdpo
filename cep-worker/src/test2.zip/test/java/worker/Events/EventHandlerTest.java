package worker.Events;

import com.github.fridujo.rabbitmq.mock.MockConnectionFactory;
import com.rabbitmq.client.*;
import junit.framework.TestCase;
import org.apache.avro.Schema;
import worker.Connections.RabbitmqSender;
import worker.utils.Serializer;
import worker.utils.SerializerTest;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class EventHandlerTest extends TestCase{

    public void testHandle() throws IOException, TimeoutException {
        ConnectionFactory factory = new MockConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        String queueName = channel.queueDeclare().getQueue();

        RabbitmqSender sender  = new RabbitmqSender(channel);
        EventHandler eventHandler = new EventHandler();
        String query1 = "SELECT * FROM MyAvroEvent as VanLocation WHERE carType = \"Van\" ";
        String query2 = "SELECT carType,carId FROM MyAvroEvent as Location WHERE carId = 7 ";
        String fields = "carId int, carType String";

        //eventHandler.addInputStream("1","MyAvroEvent",fields);
        eventHandler.addInputStream("1","MyAvroEvent",SerializerTest.generateSchema());
        eventHandler.addCheckExpression("2","VanLocation",query1,sender);
        eventHandler.addCheckExpression("3","Location",query2, sender);

        channel.queueBind(queueName, "EXCHANGE", "1");

        eventHandler.handle(SerializerTest.generateEvent(),"MyAvroEvent");
        eventHandler.handle(SerializerTest.generateEventTruck(),"MyAvroEvent");

        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       AMQP.BasicProperties properties, byte[] body) throws IOException {
                assertEquals(SerializerTest.generateEvent(), Serializer.AvroDeserialize(body,SerializerTest.generateSchema()));
            }
        };
        channel.basicConsume(queueName, true, consumer);
        eventHandler.deleteCheckExpression("3");
        eventHandler.deleteCheckExpression("2");
        eventHandler.deleteInputStream("1");
        channel.close();
        connection.close();
    }

    public void testAggregation() throws IOException, TimeoutException {
        ConnectionFactory factory = new MockConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();
        String queueName = channel.queueDeclare().getQueue();

        RabbitmqSender sender  = new RabbitmqSender(channel);
        EventHandler eventHandler = new EventHandler();
        String query = "SELECT average from MyAvroEvent#length(4)#uni(carId)";
        String fields = "carId int, carType String";

        //eventHandler.addInputStream("1","MyAvroEvent",fields);
        eventHandler.addInputStream("1","MyAvroEvent",SerializerTest.generateSchema());
        eventHandler.addCheckExpression("2","media",query,sender);


        channel.queueBind(queueName, "EXCHANGE", "1");

        eventHandler.handle(SerializerTest.generateEvent(),"MyAvroEvent");
        eventHandler.handle(SerializerTest.generateEventTruck(),"MyAvroEvent");
        eventHandler.handle(SerializerTest.generateEvent(),"MyAvroEvent");
        eventHandler.handle(SerializerTest.generateEventTruck(),"MyAvroEvent");

        Schema schema = eventHandler.getSchema("2");
        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,
                                       AMQP.BasicProperties properties, byte[] body) throws IOException {

                assertEquals(schema.getFields(),Serializer.AvroDeserialize(body,schema).getSchema().getFields());
            }
        };
        channel.basicConsume(queueName, true, consumer);
        eventHandler.deleteCheckExpression("2");
        eventHandler.deleteInputStream("1");
        channel.close();
        connection.close();

    }

}
